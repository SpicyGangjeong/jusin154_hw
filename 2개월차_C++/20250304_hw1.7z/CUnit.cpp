#include "pch.h"
#include "CUnit.h"

CUnit::CUnit()
{
	m_pInfo = nullptr;
}

CUnit::~CUnit()
{
}
