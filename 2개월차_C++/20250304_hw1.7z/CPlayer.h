#pragma once
#include "CUnit.h"
class CPlayer final :
    public CUnit
{
public:
    CPlayer();
    ~CPlayer();
    void Initialize() override;
    void Initialize(const string& _strName);
    static CUnit* SelectJob();
    void Update() override;
    void Release() override;
    void Render() override;
    int Fight(CUnit* other);
    void putGear(const string& _strGearName);
    void manageGear();
    void checkLevel();
    INFO* getInfo() override;
};

