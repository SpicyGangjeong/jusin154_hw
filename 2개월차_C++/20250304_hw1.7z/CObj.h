#pragma once
#include "pch.h"

class CObj abstract
{
protected:
	virtual void Initialize() = 0;
	virtual void Update() = 0;
	virtual void Release() = 0;
public:
	CObj() {};
	virtual ~CObj() {};
};