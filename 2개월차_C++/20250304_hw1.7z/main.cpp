#include "pch.h"
#include "CMainGame.h"

int main() {
    CMainGame mainGame;

    mainGame.Initialize();
    mainGame.Update();

    return 0;
}
