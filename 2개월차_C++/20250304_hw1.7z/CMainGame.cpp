#include "pch.h"
#include "CMainGame.h"

CMainGame::CMainGame() : m_pPlayer(nullptr), m_pMonster(nullptr)
{

}

CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Initialize()
{
	if (nullptr == m_pPlayer) {
		m_pPlayer = CPlayer::SelectJob();
	}
	if (nullptr == m_pMonster) {
		m_pMonster = new CMonster();
	}
}

void CMainGame::Update()
{
	if (nullptr == m_pPlayer) {
		return;
	}
	int iInput = 0;
	while (true) {
		SYSTEM_CLS;
		m_pPlayer->Render();
		cout << "1. �����  2. ����  3. ��� ���� 4. ���� >> ";
		cin >> iInput;
		switch (iInput)
		{
		case 1:
			LevelMenu();
			break;
		case 2:
			ShopMenu();
			break;
		case 3:
			InventoryMenu();
			break;
		case 4:
			return;
		default:
			break;
		}
	}
}

void CMainGame::Release()
{
	Safe_Delete(m_pPlayer);
	Safe_Delete(m_pMonster);
}

void CMainGame::LevelMenu()
{
#ifdef _DEBUG
	int iInput = 0;
	CMonster* pTempMonster = dynamic_cast<CMonster*>(m_pMonster);
	CPlayer* pTempPlayer = dynamic_cast<CPlayer*>(m_pPlayer);
	if (nullptr == pTempMonster) {
		cout << " �������� ��¼�� " << endl;
		SYSTEM_PAUSE;
		exit(1);
	}
	while (true) {
		SYSTEM_CLS;
		m_pPlayer->Render();
		cout << "1. �ʱ�  2. �߱�  3. ����  4. �ڷΰ��� >> ";
		cin >> iInput;
		switch (iInput)
		{
		case 1:
			pTempMonster->Initialize("�ʱ�", iInput);
			break;
		case 2:
			pTempMonster->Initialize("�߱�", iInput);
			break;
		case 3:
			pTempMonster->Initialize("����", iInput);
			break;
		case 4:
			return;
		default:
			continue;
		}
		EncounterMenu(pTempPlayer);
	}
#endif
#ifndef _DEBUG
	int iInput = 0;
	CMonster* pTempMonster = static_cast<CMonster*>(m_pMonster);
	CPlayer* pTempPlayer = static_cast<CPlayer*>(m_pPlayer);
	while (true) {
		SYSTEM_CLS;
		m_pPlayer->Render();
		cout << "1. �ʱ�  2. �߱�  3. ����  4. �ڷΰ��� >> ";
		cin >> iInput;
		switch (iInput)
		{
		case 1:
			pTempMonster->Initialize("�ʱ�", iInput);
			break;
		case 2:
			pTempMonster->Initialize("�߱�", iInput);
			break;
		case 3:
			pTempMonster->Initialize("����", iInput);
			break;
		case 4:
			return;
		default:
			continue;
		}
		EncounterMenu(pTempPlayer);
	}
#endif
}

void CMainGame::EncounterMenu(CPlayer* pTempPlayer)
{
	int iInput = 0;
	while (true) {
		SYSTEM_CLS;
		m_pPlayer->Render();
		m_pMonster->Render();
		cout << "1. ����  2. ���� >> ";
		cin >> iInput;
		switch (iInput)
		{
		case 1:
			switch (pTempPlayer->Fight(m_pMonster)) {
			case 1: // �й�
				pTempPlayer->getInfo()->iHp = 100;
				return;
			case 2: // �¸�
				pTempPlayer->getInfo()->iExp += (m_pMonster->getInfo()->iLevel * 3);
				pTempPlayer->checkLevel();
				return;
			default:
				continue;
			}
			break;
		case 2:
			return;
		default:
			break;
		}
	}
}

void CMainGame::ShopMenu()
{
	CPlayer* pTempPlayer;
#ifdef _DEBUG
	pTempPlayer = dynamic_cast<CPlayer*>(m_pPlayer);
	if (nullptr == pTempPlayer) {
		cout << " �������� ��¼�� " << endl;
		SYSTEM_PAUSE;
		exit(1);
	}
#endif
#ifndef _DEBUG
	pTempPlayer = static_cast<CPlayer*>(m_pPlayer);
#endif // !_DEBUG

	int iInput = 0;
	while (true) {
		SYSTEM_CLS;
		m_pPlayer->Render();
		string strGear = "";
		cout << "1. ����  2. ��  3. �ȱ� 4. ������ >> ";
		cin >> iInput;
		switch (iInput)
		{
		case 1:
			strGear.append("����");
			break;
		case 2:
			strGear.append("��");
			break;
		case 3: 
		{
			if (pTempPlayer->getInfo()->Inventory->size() == 0) {
				cout << "�� ��� �����ϴ�" << endl;
				SYSTEM_PAUSE;
				continue;
			}
			vector<CItem*>::iterator iterInventory = pTempPlayer->getInfo()->Inventory->begin();
			cout << "�κ��丮 ��� >> ";
			cout << endl;
			for (int i = 0; i < pTempPlayer->getInfo()->Inventory->size();) {
				cout << i << ". " << (*iterInventory)->getName() << endl;
				++iterInventory;
				++i;
			}
			iterInventory = pTempPlayer->getInfo()->Inventory->begin();
			cout << "�Ǹ� �� ��� ����ּ���. (��� ��ȣ) >> ";
			cin >> iInput;
			iterInventory += iInput;
			pTempPlayer->getInfo()->Inventory->erase(iterInventory);
		}
			continue;
		case 4:
			return;
		default:
			continue;
		}
		while (true) {
			SYSTEM_CLS;
			m_pPlayer->Render();
			string grade = "";
			cout << "1. �ʱ�  2. �߱�  3. ����  4. ������ >> ";
			cin >> iInput;
			switch (iInput)
			{
			case 1:
				grade.append("�ʱ�");
				grade.append(strGear);
				pTempPlayer->putGear(grade);
				return;
			case 2:
				grade.append("�߱�");
				grade.append(strGear);
				pTempPlayer->putGear(grade);
				return;
			case 3:
				grade.append("����");
				grade.append(strGear);
				pTempPlayer->putGear(grade);
				return;
			case 4:
				return;
			default:
				break;
			}
		}
	}
}

void CMainGame::InventoryMenu()
{
	CPlayer* pTempPlayer;
#ifdef _DEBUG
	pTempPlayer = dynamic_cast<CPlayer*>(m_pPlayer);
	if (nullptr == pTempPlayer) {
		cout << " �������� ��¼�� " << endl;
		SYSTEM_PAUSE;
		exit(1);
	}
#endif
#ifndef _DEBUG
	pTempPlayer = static_cast<CPlayer*>(m_pPlayer);
#endif // !_DEBUG
	pTempPlayer->manageGear();
}
