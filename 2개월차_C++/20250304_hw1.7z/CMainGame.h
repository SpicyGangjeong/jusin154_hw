#pragma once
#include "CObj.h"
#include "CUnit.h"
#include "CPlayer.h"
#include "CMonster.h"


class CMainGame :
    public CObj
{
private:
    CUnit* m_pPlayer;
    CUnit* m_pMonster;

public:
    CMainGame();
    ~CMainGame();
    void Initialize() override;
    void Update() override;
    void Release() override;
public:
    void LevelMenu();
    void EncounterMenu(CPlayer* pTempPlayer);
    void ShopMenu();
    void InventoryMenu();
};

