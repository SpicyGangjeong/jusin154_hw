#pragma once
#include "CObj.h"
class CItem final:
    public CObj
{
private:
    string m_strName;
public:
    CItem();
    ~CItem();

public:
    void Initialize() override;
    void Initialize(const string& _strName);
    void Update() override;
    void Release() override;

    string& getName();
private:
    void setName(const string& _strName);
};

