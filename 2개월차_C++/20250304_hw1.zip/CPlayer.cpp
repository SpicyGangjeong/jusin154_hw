#include "pch.h"
#include "CPlayer.h"
#include "Define.h"

CPlayer::CPlayer()
{
	m_pInfo = nullptr;
}

CPlayer::~CPlayer()
{
	Release();
}

void CPlayer::Initialize()
{
}

void CPlayer::Initialize(const string& _strName)
{
	if (nullptr == m_pInfo) {
		m_pInfo = new INFO;
		m_pInfo->strName = _strName;
		m_pInfo->iMaxHp = 100;
		m_pInfo->iHp = 100;
		m_pInfo->iAttack = 10;
		m_pInfo->iLevel = 1;
		m_pInfo->iExp = 0;
		m_pInfo->Inventory = new vector<CItem*>;
		m_pInfo->Inventory->reserve(5);
	}
}

CUnit* CPlayer::SelectJob()
{
	CPlayer* temp = nullptr;
	int iInput = 0;
	while (nullptr == temp) {
		cout << "1. ����  2. ����  3. ������  4. ���� >> ";
		cin >> iInput;
		switch (iInput)
		{
		case 1:
			temp = new CPlayer();
			temp->Initialize("����");
			break;
		case 2:
			temp = new CPlayer();
			temp->Initialize("����");
			break;
		case 3:
			temp = new CPlayer();
			temp->Initialize("������");
			break;
		case 4:
			return nullptr;
		default:
			break;
		}
	}
	return temp;
}

void CPlayer::Update()
{
}

void CPlayer::Release()
{
	Safe_Delete(m_pInfo);
}

void CPlayer::Render()
{
	cout << "========================\n";
	cout << "����: " << m_pInfo->strName << "\t����: " << m_pInfo->iLevel << '(' << m_pInfo->iExp << '/' << m_pInfo->iLevel * 5 << ")\n";
	cout << "ü��: " << m_pInfo->iHp << " / " << m_pInfo->iMaxHp << "\t���ݷ�" << m_pInfo->iAttack << '\n';
	cout << "������ ��� >> ";
	for (CItem* pItem : *m_pInfo->Inventory) {
		cout << pItem->getName() << ' ';
	}
	cout << endl;
}

int CPlayer::Fight(CUnit* other)
{
	m_pInfo->iHp -= other->getInfo()->iAttack;
	if (m_pInfo->iHp <= 0) {
		m_pInfo->iHp = 0;
		cout << "�й�" << endl;
		return 1;
	}
	other->getInfo()->iHp -= m_pInfo->iAttack;
	if (other->getInfo()->iHp <= 0) {
		other->getInfo()->iHp = 0;
		cout << "�¸�" << endl;
		return 2;
	}
	return 0;
}

void CPlayer::putGear(const string& _strGearName)
{
	CItem* tempItem = new CItem();
	tempItem->Initialize(_strGearName);
	if (m_pInfo->Inventory->size() == 5) {
		cout << "������ �� �����ϴ�. �κ��丮�� ���� á���ϴ�." << endl;
		SYSTEM_PAUSE;
		return;
	}
	m_pInfo->Inventory->push_back(tempItem);
}

void CPlayer::checkLevel()
{
	if (m_pInfo->iExp >= m_pInfo->iLevel * 5) {
		SYSTEM_CLS;
		Render();
		m_pInfo->iExp = 0;
		m_pInfo->iLevel++;
		cout << "!!!!������!!!!" << endl;
		Render();
		SYSTEM_PAUSE;
	}
}

INFO* CPlayer::getInfo()
{
	return m_pInfo;
}
