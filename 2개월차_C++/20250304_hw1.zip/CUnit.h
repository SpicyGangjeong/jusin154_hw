#pragma once
#include "CObj.h"
#include "Define.h"
class CUnit abstract:
    public CObj
{
protected:
    INFO* m_pInfo;

public:
    CUnit();
    virtual ~CUnit();
    virtual void Render() = 0;
    virtual INFO* getInfo() = 0;
};

