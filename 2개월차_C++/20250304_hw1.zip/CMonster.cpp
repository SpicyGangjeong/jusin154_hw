#include "pch.h"
#include "CMonster.h"

CMonster::CMonster()
{
}

CMonster::~CMonster()
{
	Release();
}

void CMonster::Initialize()
{

}

void CMonster::Initialize(const string _strName, int _iLevel)
{
	if (nullptr == m_pInfo) {
		m_pInfo = new INFO;
	}
	m_pInfo->strName = _strName;
	m_pInfo->iHp = _iLevel * 30;
	m_pInfo->iMaxHp = _iLevel * 30;
	m_pInfo->iAttack = _iLevel * 3;
	m_pInfo->iLevel = _iLevel;
	m_pInfo->iExp = _iLevel * 2;
	m_pInfo->Inventory = nullptr;
}

void CMonster::Update()
{
}

void CMonster::Release()
{
	Safe_Delete(m_pInfo);
}

void CMonster::Render()
{
	cout << "========================\n";
	cout << "���̵�: " << m_pInfo->strName << ")\n";
	cout << "ü��: " << m_pInfo->iHp << " / " << m_pInfo->iMaxHp << "\t���ݷ�" << m_pInfo->iAttack << endl;

}

INFO* CMonster::getInfo()
{
	return m_pInfo;
}
