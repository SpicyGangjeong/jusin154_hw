#pragma once
#include "CItem.h"

template<typename T>
void Safe_Delete(T& p) {
	if (p) {
		delete p;
		p = nullptr;
	}
}

template<typename T>
void Safe_Delete_Array(T& p) {
	if (p) {
		delete[] p;
		p = nullptr;
	}
}

#define SYSTEM_CLS			system("cls");
#define SYSTEM_PAUSE		system("pause");

typedef struct tagInfo {
	int iHp = 0;
	int iMaxHp = 0;
	int iAttack = 0;
	int iLevel = 0;
	int iExp = 0;
	string strName = "";
	vector<CItem*>* Inventory = nullptr;
} INFO;