#pragma once
#include "CUnit.h"
class CMonster final:
    public CUnit
{
public:
    CMonster();
    ~CMonster();
    
public:
    void Initialize() override;
    void Initialize(const string _strName, int _iLevel);
    void Update() override;
    void Release() override;
    void Render() override;
    INFO* getInfo() override;
};

