#include "pch.h"
#include "CItem.h"

CItem::CItem(): m_strName("")
{
}

CItem::~CItem()
{
    Release();
}

void CItem::Initialize()
{
}

void CItem::Initialize(const string& _strName)
{
    setName(_strName);
}

void CItem::Update()
{
}

void CItem::Release()
{
    
}

string& CItem::getName() {
    return m_strName;
}

void CItem::setName(const string& _strName) {
    m_strName = _strName;
}