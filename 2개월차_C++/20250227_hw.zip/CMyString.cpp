#include "pch.h"
#include "CMyString.h"

CMyString::CMyString():CMyString(32)
{
    
}

CMyString::CMyString(int _iSize) : m_iCurrentSize(0)
{
    m_iMaxSize = 32;
    m_szContent = new char[m_iMaxSize];
    memset(m_szContent, 0, m_iMaxSize);
    m_iCurrentSize = strlen(m_szContent);
}

CMyString::~CMyString()
{
    Release();
}

void CMyString::Release()
{
    if (m_szContent) {
        delete m_szContent;
        m_szContent = nullptr;
    }
}

int CMyString::Get_CurrentSize()
{
    return m_iCurrentSize;
}

int CMyString::Get_iMaxSize()
{
    return m_iMaxSize;
}

const char* CMyString::Get_Content()
{
    return m_szContent;
}

void CMyString::operator=(CMyString& other)
{
    if (m_iMaxSize < other.Get_CurrentSize()) {
        strcpy_s(m_szContent, sizeof(other.Get_Content()) + 1, other.Get_Content());
        m_iCurrentSize = strlen(m_szContent);
        return;
    }
    Release();
    while (m_iMaxSize <= other.Get_CurrentSize()) {
        m_iMaxSize <<= 1;
    }
    m_szContent = new char[m_iMaxSize];
    strcpy_s(m_szContent, sizeof(other.Get_Content()) + 1, other.Get_Content());
    m_iCurrentSize = strlen(m_szContent);
    return;
}

void CMyString::operator=(const char* other)
{
    if (m_iMaxSize < strlen(other)) {
        strcpy_s(m_szContent, sizeof(other) + 1, other);
        m_iCurrentSize = strlen(m_szContent);
        return;
    }
    Release();
    while (m_iMaxSize <= strlen(other)) {
        m_iMaxSize <<= 1;
    }
    m_szContent = new char[m_iMaxSize];
    strcpy_s(m_szContent, sizeof(other) + 1, other);
    m_iCurrentSize = strlen(m_szContent);
    return;
}

void CMyString::operator+=(CMyString& other)
{
    int iNewMaxSize = strlen(m_szContent) + strlen(other.Get_Content()) + 1;
    char* _szNewContent = new char[iNewMaxSize];
    memset(_szNewContent, 0, iNewMaxSize);
    strcat_s(_szNewContent, strlen(m_szContent) + strlen(other.Get_Content()) + 1, m_szContent);
    strcat_s(_szNewContent, strlen(m_szContent) + strlen(other.Get_Content()) + 1, other.Get_Content());
    Release();
    m_szContent = _szNewContent;
    m_iMaxSize = iNewMaxSize;
    m_iCurrentSize = strlen(m_szContent);
}

const char*  CMyString::operator+(CMyString& other)
{
    int iNewMaxSize = strlen(m_szContent) + strlen(other.Get_Content()) + 1;
    char* _szNewContent = new char[iNewMaxSize];
    memset(_szNewContent, 0, iNewMaxSize);
    strcat_s(_szNewContent, strlen(m_szContent) + strlen(other.Get_Content()) + 1, m_szContent);
    strcat_s(_szNewContent, strlen(m_szContent) + strlen(other.Get_Content()) + 1, other.Get_Content());
    return _szNewContent;
}

bool CMyString::operator==(CMyString& other)
{
    return (0 == strcmp(m_szContent, other.Get_Content()));
}
