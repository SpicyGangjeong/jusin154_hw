#include "pch.h"
#include "CMyString.h"

using namespace std;

int main() {
	CMyString str1(4);

	str1 = "hello";
	cout << str1.Get_Content() << endl; // hello

	CMyString str2(8);

	str2 = "world";
	cout << str2.Get_Content() << endl; // world

	CMyString strDummy;

	strDummy = str1;
	cout << strDummy.Get_Content() << endl; // hello
	cout << (str1 == strDummy) << endl;		// 1
	cout << (str1 == str2) << endl;			// 0

	cout << str1 + str2 << endl;
	cout << strDummy.Get_Content() << endl;
	strDummy += str2;
	cout << strDummy.Get_Content() << endl;



	return 0;
}