#include "pch.h"
#include "ReportManager.h"

void ReportManager::PrintSheet(SHEET* _sheet)
{
	cout << _sheet->strName << ' ' << _sheet->iKor << ' ' << _sheet->iEng << ' ' << _sheet->iMath << ' ' << _sheet->iSum << ' ' << _sheet->dEver << endl;
}

ReportManager::ReportManager() : insertNumber(0), m_Sheets(nullptr) {}

ReportManager::~ReportManager()
{
	Release();
}

void ReportManager::Initialize()
{
	if (!m_Sheets) {
		m_Sheets = new vector<SHEET*>;
		m_Sheets->reserve(32);
	}
}

void ReportManager::Update()
{
	int iInput = 0;
	while (true) {
		SYSTEM_CLS;
		cout << "1. �Է�  2. ���  3. �˻�  4. ����  5. ���� >> ";
		cin >> iInput;

		switch (iInput)
		{
		case 1:
			Insert();
			break;
		case 2:
			Render();
			break;
		case 3:
			Search();
			break;
		case 4:
			Delete();
			break;
		case 5:
			return;
		default:
			break;
		}
	}
}

void ReportManager::Release()
{
	Safe_Delete(m_Sheets);
}

void ReportManager::Render()
{
	SYSTEM_CLS;
	cout << "���ı���: ���Լ�" << endl;
	cout << "�̸�\t����\t����\t����\t�հ�\t���" << endl;
	for (SHEET* pSheet : *m_Sheets) {
		PrintSheet(pSheet);
	}
	SYSTEM_PAUSE;
}

void ReportManager::Insert()
{
	int iInput = 0;
	SHEET* pTempSheet = new SHEET;
	while (true) {
		cout << "�̸� �Է� >> ";
		cin >> pTempSheet->strName;
		cout << "���� �Է� >> ";
		cin >> pTempSheet->iKor;
		cout << "���� �Է� >> ";
		cin >> pTempSheet->iEng;
		cout << "���� �Է� >> ";
		cin >> pTempSheet->iMath;
		pTempSheet->iSum = pTempSheet->iKor + pTempSheet->iEng + pTempSheet->iMath;
		pTempSheet->dEver = double(pTempSheet->iSum) / 3;
		PrintSheet(pTempSheet);
		cout << "�� ������ �½��ϱ�? \n 1. ��  2. �ƴϿ� >> ";
		cin >> iInput;
		if (iInput == 1) {
			pTempSheet->iNumber = insertNumber++;
			m_Sheets->push_back(pTempSheet);
			return;
		}
	}
}

void ReportManager::Search()
{
	SYSTEM_CLS;
	string strSearchValue;
	cout << "ã������ �л��� �̸� �Է� >> ";
	cin >> strSearchValue;
	vector<SHEET*>::iterator iter = m_Sheets->begin();
	while (true) {
		if (iter == m_Sheets->end()) {
			break;
		}
		if ((*iter)->strName == strSearchValue) {
			PrintSheet(*iter);
		}
		iter++;
	}
	SYSTEM_PAUSE;
}

void ReportManager::Delete()
{
	SYSTEM_CLS;
	string strSearchValue;
	cout << "������� �л��� �̸� �Է� >> ";
	cin >> strSearchValue;
	vector<SHEET*>::iterator iter = m_Sheets->begin();
	while (true) {
		if (iter == m_Sheets->end()) {
			break;
		}
		if ((*iter)->strName == strSearchValue) {
			iter = m_Sheets->erase(iter);
		}
		else {
			iter++;
		}
	}
	cout << "��� ������." << endl;
	SYSTEM_PAUSE;
}
