#pragma once
#include "pch.h"

template<typename T>
void Safe_Delete(T& p) {
	if (p) {
		delete p;
		p = nullptr;
	}
}
template<typename T>
void Safe_Delete_Array(T& p) {
	if (p) {
		delete[] p;
		p = nullptr;
	}
}

#define SYSTEM_CLS			system("cls");
#define SYSTEM_PAUSE		system("pause");

/*
int iNumber;
int iKor, iEng, iMath, iSum;
string strName;
double dEver;
*/
typedef struct tagSheet {
	int iNumber;
	int iKor, iEng, iMath, iSum;
	string strName;
	double dEver;
} SHEET;