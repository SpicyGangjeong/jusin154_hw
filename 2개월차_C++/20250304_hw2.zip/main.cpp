#include "pch.h"
#include "ReportManager.h"


int main() {
	ReportManager reportManager;

	reportManager.Initialize();
	reportManager.Update();






	return 0;
}