#include "pch.h"
#include "CPlayer.h"

CPlayer::CPlayer() : m_pBulletList(nullptr)
{
}

CPlayer::~CPlayer()
{
	Release();
}

void CPlayer::Initialize()
{
	m_fSpeed = 10.f;
}

int CPlayer::Update()
{
	__super::Update_Rect();

	Key_Input();

	return NORESULT;
}

int CPlayer::Late_Update()
{
	//if (m_bDead) {
	//	return DEAD;
	//}
	return NORESULT;
}

void CPlayer::Render(HDC hDC)
{
	Rectangle(hDC,
		m_tRect.left, m_tRect.top,
		m_tRect.right, m_tRect.bottom);
	Ellipse(hDC, 
		m_tRect.left, m_tRect.top, 
		m_tRect.right, m_tRect.bottom );
	MoveToEx(hDC, m_tInfo.fX, m_tInfo.fY, NULL);
	int iRocationX = (m_tInfo.fCX) * cos(m_tInfo.dRadian);
	int iRocationY = (m_tInfo.fCX) * sin(m_tInfo.dRadian);
	LineTo(hDC, m_tInfo.fX + iRocationX, m_tInfo.fY + iRocationY);
}

void CPlayer::Release()
{
}

void CPlayer::Set_BulletList(list<CObj*>* _pList) {
	m_pBulletList = _pList;
}

void CPlayer::Key_Input()
{
	if (GetAsyncKeyState(VK_RIGHT))
	{
		m_tInfo.fX += m_fSpeed;
	}

	if (GetAsyncKeyState(VK_LEFT))
	{
		m_tInfo.fX -= m_fSpeed;
	}

	if (GetAsyncKeyState(VK_UP))
	{
		m_tInfo.fY -= m_fSpeed;
	}

	if (GetAsyncKeyState(VK_DOWN))
	{
		m_tInfo.fY += m_fSpeed;
	}

	if (GetAsyncKeyState('A')) {
		m_tInfo.dRadian += (PI / 180.0);
	}
	
	if (GetAsyncKeyState('D')) {
		m_tInfo.dRadian -= (PI / 180.0);
	}

	if (GetAsyncKeyState(VK_SPACE)) {
		m_pBulletList->push_back(
			CAbstractFactory<CBullet>::
				Create_Obj(m_tInfo.fX, m_tInfo.fY, 15.f, 15.f, m_tInfo.dRadian)
		);
	}
}