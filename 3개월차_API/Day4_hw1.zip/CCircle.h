#pragma once
#include "CObj.h"
class CCircle :
    public CObj
{
public:
    CCircle();
    ~CCircle();
public:
    void Initialize() override;
    int Update() override;
    int Late_Update() override;
    void Render(HDC hDC) override;
    void Release() override;

};

