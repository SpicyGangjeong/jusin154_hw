#pragma once

template<typename T>
class CAbstractFactory
{
public:
	CAbstractFactory() {};
	~CAbstractFactory() {};
public:
	static CObj* Create_Obj(float _fPivotX, float _fPivotY, float _fCX, float _fCY, double _dRadian = 0.0) {
		CObj* pObj = new T;
		pObj->Initialize();
		pObj->Set_Info(_fPivotX, _fPivotY, _fCX, _fCY, _dRadian);
		return pObj;
	}
};

