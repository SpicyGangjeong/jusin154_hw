#include "pch.h"
#include "CMainGame.h"
#include "CAbstractFactory.h"
#include "CCollisionManager.h"
#include "CPlayer.h"
#include "CCircle.h"

CMainGame::CMainGame() : m_hDC(NULL)
{
}

CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Initialize()
{
	m_hDC = GetDC(g_hWnd);
	m_ObjList[OBJ_PLAYER].push_back(CAbstractFactory<CPlayer>::Create_Obj(WINCX / 2.f, WINCY / 2.f, 100.f, 100.f));
	dynamic_cast<CPlayer*>(m_ObjList[OBJ_PLAYER].front())->Set_BulletList(&m_ObjList[OBJ_BULLET]);
	
	int width = WINCX / 9;
	int height = WINCY / 9;
	for (float i = 1.f; i <= 9.f; ++i) {
		for (float j = 1.f; j <= 9.f; ++j) {
			m_ObjList[OBJ_MONSTER].push_back(CAbstractFactory<CCircle>::Create_Obj(width * i, height * j, 45.f, 45.f));
		}
	}
	

}

void CMainGame::Update()
{
	for (int i = 0; i < OBJ_END; ++i) {
		for (auto iter = m_ObjList[i].begin();
			iter != m_ObjList[i].end();) {
			int iResult = (*iter)->Update();
			if (DEAD == iResult) {
				Safe_Delete<CObj*>(*iter);
				iter = m_ObjList[i].erase(iter);
			}
			else {
				++iter;
			}
		}
	}
}

void CMainGame::Late_Update()
{
	CCollisionManager::Collision_Rect(m_ObjList[OBJ_PLAYER], m_ObjList[OBJ_MONSTER]);
	CCollisionManager::Collision_Rect(m_ObjList[OBJ_BULLET], m_ObjList[OBJ_MONSTER]);
	for (int i = 0; i < OBJ_END; ++i) {
		for (auto iter = m_ObjList[i].begin();
			iter != m_ObjList[i].end();) {
			int iResult = (*iter)->Late_Update();
			if (DEAD == iResult) {
				Safe_Delete<CObj*>(*iter);
				iter = m_ObjList[i].erase(iter);
			}
			else {
				++iter;
			}
		}
	}
}

void CMainGame::Render()
{
	Rectangle(m_hDC, 0, 0, WINCX, WINCY);

	for (int i = 0; i < OBJ_END; ++i) {
		for (auto iter = m_ObjList[i].begin();
			iter != m_ObjList[i].end();) {
			(*iter)->Render(m_hDC);
			++iter;
		}
	}
}

void CMainGame::Release()
{
	for (int i = 0; i < OBJ_END; ++i) {
		for_each(m_ObjList[i].begin(), m_ObjList[i].end(), Safe_Delete<CObj*>);
	}
	ReleaseDC(g_hWnd, m_hDC);
}
