#pragma once

#include "pch.h"
#include "Define.h"
#include "CObj.h"

class CMainGame
{
public:
	CMainGame();
	~CMainGame();

public:
	void		Initialize();
	void		Update();
	void		Late_Update();
	void		Render();
	void		Release();

private:
	HDC		m_hDC;
	list<CObj*>		m_ObjList[OBJ_END];
	list<CObj*>		m_BulletList;
};