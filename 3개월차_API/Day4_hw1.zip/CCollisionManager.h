#pragma once
#include "CObj.h"

class CCollisionManager
{
public:
	static bool	Collision_Rect(list<CObj*> DstList, list<CObj*> SrcList);
};

