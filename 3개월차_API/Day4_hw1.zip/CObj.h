#pragma once

#include "Define.h"

class CObj
{
public:
	CObj();
	virtual ~CObj();

public:
	const INFO* Get_Info() { return &m_tInfo; }

public:
	virtual void	Initialize()PURE;
	virtual int		Update()PURE;
	virtual int		Late_Update()PURE;
	virtual void	Render(HDC hDC)PURE;
	virtual void	Release()PURE;

public:
	void		Update_Rect();
	void		Set_Info(float _fPivotX, float _fPivotY, float _fCX, float _fCY, double _dRadian);
	void		Set_Dead() { m_bDead = true; }
	RECT*		Get_Rect() { return &m_tRect; }

protected:
	INFO		m_tInfo;
	RECT		m_tRect;

	float		m_fSpeed;
	bool		m_bDead;

};

