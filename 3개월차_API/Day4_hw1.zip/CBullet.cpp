#include "pch.h"
#include "CBullet.h"

CBullet::CBullet() {

}

CBullet::~CBullet() {
	Release();
}

void CBullet::Initialize()
{
	m_fSpeed = 15.f;
}

int CBullet::Update()
{
	__super::Update_Rect();
	int iRocationX = (m_fSpeed)*cos(m_tInfo.dRadian);
	int iRocationY = (m_fSpeed)*sin(m_tInfo.dRadian);
	m_tInfo.fX += iRocationX;
	m_tInfo.fY += iRocationY;
	return NORESULT;
}

int CBullet::Late_Update()
{
	if (m_bDead) {
		return DEAD;
	}
	return NORESULT;
}

void CBullet::Render(HDC hDC)
{
	Ellipse(hDC,
		m_tRect.left, m_tRect.top,
		m_tRect.right, m_tRect.bottom);
}

void CBullet::Release()
{

}
