#include "pch.h"
#include "CCircle.h"

CCircle::CCircle()
{

}

CCircle::~CCircle()
{
	Release();
}

void CCircle::Initialize()
{
	m_tInfo = { };
	m_fSpeed = 0.f;
}

int CCircle::Update()
{
	__super::Update_Rect();

	return NORESULT;
}

int CCircle::Late_Update()
{
	if (m_bDead) {
		return DEAD;
	}
	return NORESULT;
}

void CCircle::Render(HDC hDC)
{
	Ellipse(hDC, m_tRect.left, m_tRect.top, m_tRect.right, m_tRect.bottom);
}

void CCircle::Release()
{

}

