#pragma once

typedef struct tagCIRCLE {
    long centerX;
    long centerY;
    long length;
    double radian;
} CIRCLE;

#define PI 3.141592f
#define WINCX 800
#define WINCY 600


template<typename T>
void Safe_Delete(T& p) {
    if (p) {
        delete p;
        p = nullptr;
    }
}
template<typename T>
void Safe_Delete_Array(T& p) {
    if (p) {
        delete[] p;
        p = nullptr;
    }
}