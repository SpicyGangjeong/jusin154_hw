#include "pch.h"
#include "CBullet.h"

CBullet::CBullet() : m_dRadius(0), m_iOrbitalLength(90), m_fTrackX(0), m_fTrackY(0)
{
}

CBullet::~CBullet()
{
}

void CBullet::Initialize()
{
	m_tInfo.fCX = 40.f;
	m_tInfo.fCY = 40.f;

	m_fSpeed = 5.f;
}


void CBullet::Late_Initialize()
{
	m_fTrackX = m_tInfo.fX;
	m_fTrackY = m_tInfo.fY;

}

int CBullet::Update()
{
	if (m_bDead)
		return DEAD;

	__super::Update_Rect();

	m_dRadius += ((rand() % 45) + 1) * (PI / 180.f);
	m_dRadius >= 2 * PI ? m_dRadius -= 2 * PI : true;

	m_fTrackX += m_fSpeed * cosf(m_fAngle * (PI / 180.f));
	m_fTrackY -= m_fSpeed * sinf(m_fAngle * (PI / 180.f));

	m_tInfo.fX = m_fTrackX + (m_iOrbitalLength * cos(m_dRadius));
	m_tInfo.fY = m_fTrackY + (m_iOrbitalLength * sin(m_dRadius));

	return NOEVENT;
}

void CBullet::Late_Update()
{

}



void CBullet::Render(HDC hDC)
{
	Ellipse(hDC,
		m_tRect.left, m_tRect.top,
		m_tRect.right, m_tRect.bottom);
}

void CBullet::Release()
{
}
