#include "pch.h"
#include "CMonster.h"

CMonster::CMonster(): m_dRadian(0)
{
}

CMonster::~CMonster()
{
	Release();
}

void CMonster::Initialize()
{
	m_tInfo.fCX = 25.f;
	m_tInfo.fCY = 25.f;

	m_fSpeed = 2.f;
}

int CMonster::Update()
{
	if (m_bDead)
		return DEAD;

	int diffX = m_pPlayer->Get_Info()->fX - m_tInfo.fX;
	int diffY = m_pPlayer->Get_Info()->fY - m_tInfo.fY;

	m_dRadian = asin( pow(diffY, 2) / (pow(diffX, 2) + pow(diffY, 2)) );
	if (diffX > 0) {
		m_tInfo.fX += (m_fSpeed * cos(m_dRadian));
	}
	else {
		m_tInfo.fX -= (m_fSpeed * cos(m_dRadian));
	}

	if (diffY > 0) {
		m_tInfo.fY += (m_fSpeed * sin(m_dRadian));
	}
	else {
		m_tInfo.fY -= (m_fSpeed * sin(m_dRadian));
	}

	__super::Update_Rect();

	return NOEVENT;
}

void CMonster::Late_Update()
{
}

void CMonster::Render(HDC hDC)
{
	Ellipse(hDC,
		m_tRect.left, m_tRect.top,
		m_tRect.right, m_tRect.bottom);

	MoveToEx(hDC, m_tInfo.fX, m_tInfo.fY, NULL);

	LineTo(hDC, 
		(m_tInfo.fX + 20 * cos(m_dRadian)), 
		(m_tInfo.fY + 20 * sin(m_dRadian)));
}

void CMonster::Release()
{
}

void CMonster::Set_Player(CObj* _pPlayer)
{
	m_pPlayer = _pPlayer;
}

void CMonster::Late_Initialize()
{
}
