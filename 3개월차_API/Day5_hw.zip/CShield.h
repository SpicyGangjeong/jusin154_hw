#pragma once
#include "CObj.h"

class CShield :
    public CObj
{
public:
    CShield();
    ~CShield();

public:
    void Initialize() override;
    int  Update() override;
    void Late_Update() override;
    void Render(HDC hDC) override;
    void Release() override;


public:
    void Set_Player(CObj* _pPlayer);

private:
    double m_dRadius;
    int    m_iOrbitalLength;
    CObj* m_pPlayer;

    // CObj��(��) ���� ��ӵ�
    void Late_Initialize() override;
};

