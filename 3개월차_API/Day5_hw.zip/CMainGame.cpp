#include "pch.h"
#include "CMainGame.h"
#include "CPlayer.h"
#include "CShield.h"
#include "CMonster.h"
#include "CAbstractFactory.h"
#include "CCollisionMgr.h"
#include "CMouse.h"

CMainGame::CMainGame() :m_dwTime(GetTickCount64()), m_iFPS(0)
{
	ZeroMemory(m_szFPS, sizeof(m_szFPS));
}

CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Initialize()
{
	m_hDC = GetDC(g_hWnd);

	m_ObjList[OBJ_PLAYER].push_back(CAbstractFactory<CPlayer>::Create_Obj());
	dynamic_cast<CPlayer*>(m_ObjList[OBJ_PLAYER].front())->Set_BulletList(&m_ObjList[OBJ_BULLET]);

	m_ObjList[OBJ_SHIELD].push_back(CAbstractFactory<CShield>::Create_Obj());
	dynamic_cast<CShield*>(m_ObjList[OBJ_SHIELD].front())->Set_Player(m_ObjList[OBJ_PLAYER].front());
	
	// m_pPlayer = CAbstractFactory<CPlayer>::Create_Obj();
	// dynamic_cast<CPlayer*>(m_pPlayer)->Set_BulletList(&m_BulletList);

	for (int i = 0; i < 3; ++i)
	{
		for (int j = 0; j < 3; ++j) 
		{
			m_ObjList[OBJ_MONSTER].push_back(CAbstractFactory<CMonster>::Create_Obj((j + 1) * 150.f, (i + 1) * 140.f));
			dynamic_cast<CMonster*>(m_ObjList[OBJ_MONSTER].back())->Set_Player(m_ObjList[OBJ_PLAYER].front());
		}
	}

	m_ObjList[OBJ_MOUSE].push_back(CAbstractFactory<CMouse>::Create_Obj());
}

void CMainGame::Update()
{
	// m_pPlayer->Update();
	// 
	// for (auto& pBullet : m_BulletList)
	// 	pBullet->Update();

	for (size_t i = 0; i < OBJ_END; ++i)
	{
		for (auto iter = m_ObjList[i].begin();
			iter != m_ObjList[i].end(); )
		{
			int iResult = (*iter)->Update();

			if (DEAD == iResult)
			{
				Safe_Delete<CObj*>(*iter);
				iter = m_ObjList[i].erase(iter);
			}
			else
			{
				++iter;
			}
		}
	}


}

void CMainGame::Late_Update()
{
	for (size_t i = 0; i < OBJ_END; ++i)
	{
		for (auto iter = m_ObjList[i].begin();
			iter != m_ObjList[i].end(); ++iter)
		{
			(*iter)->Late_Update();
		}
	}
	CCollisionMgr::Collision_Circle(m_ObjList[OBJ_MOUSE], m_ObjList[OBJ_MONSTER]);
	CCollisionMgr::Collision_Rect(m_ObjList[OBJ_BULLET], m_ObjList[OBJ_MONSTER]);

}

void CMainGame::Render()
{
	Rectangle(m_hDC, 0, 0, WINCX, WINCY);
	Rectangle(m_hDC, 100, 100, WINCX - 100, WINCY - 100);

	for (size_t i = 0; i < OBJ_END; ++i)
	{
		for (auto iter = m_ObjList[i].begin();
			iter != m_ObjList[i].end(); ++iter)
		{
			(*iter)->Render(m_hDC);
		}
	}

}

void CMainGame::Release()
{

	for (size_t i = 0; i < OBJ_END; ++i)
	{
		for_each(m_ObjList[i].begin(), m_ObjList[i].end(), Safe_Delete<CObj*>);
		m_ObjList[i].clear();
	}


	ReleaseDC(g_hWnd, m_hDC);
}
