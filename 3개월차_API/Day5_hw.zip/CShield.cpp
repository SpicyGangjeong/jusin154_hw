#include "pch.h"
#include "CShield.h"

CShield::CShield() : m_dRadius(0.0f), m_iOrbitalLength(90)
{
}

CShield::~CShield()
{
	Release();
}

void CShield::Initialize()
{
	m_tInfo = { WINCX / 2.f, WINCY / 2.f, 25.f, 25.f };
}

int CShield::Update()
{
	m_dRadius += (PI / 180.f);
	m_dRadius >= 2 * PI ? m_dRadius -= 2 * PI : true;

	m_tInfo.fX = m_pPlayer->Get_Info()->fX + (m_iOrbitalLength * cos(m_dRadius));
	m_tInfo.fY = m_pPlayer->Get_Info()->fY + (m_iOrbitalLength * sin(m_dRadius));


	__super::Update_Rect();
	return 0;
}

void CShield::Late_Update()
{

}

void CShield::Render(HDC hDC)
{
	Ellipse(hDC,
		m_tRect.left, m_tRect.top,
		m_tRect.right, m_tRect.bottom);
}

void CShield::Release()
{
}

void CShield::Set_Player(CObj* _pPlayer)
{
	m_pPlayer = _pPlayer;
}

void CShield::Late_Initialize()
{
}
