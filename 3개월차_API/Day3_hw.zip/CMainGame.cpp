#include "pch.h"
#include "CMainGame.h"

CMainGame::CMainGame() : m_pPlayer(nullptr), m_pMonster(nullptr), m_hDC(NULL)
{
	m_rcBorder = { 100, 100, WINCX - 100, WINCY - 100 };
}

CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Initialize()
{
	m_hDC = GetDC(g_hWnd);

	if (!m_pMonster) {
		m_pMonster = new CMonster;
		m_pMonster->Initialize();
		m_pMonster->Set_Border(&m_rcBorder);
	}

	if (!m_pPlayer)
	{
		m_pPlayer = new CPlayer;
		m_pPlayer->Initialize();
		m_pPlayer->Set_Border(&m_rcBorder);
		m_pPlayer->Set_Hostile(m_pMonster);
		dynamic_cast<CPlayer*>(m_pPlayer)->Set_BulletList(&Bullets);
	}
}

void CMainGame::Update()
{
	m_pPlayer->Update();
	m_pMonster->Update();
	for (list<CObj*>::iterator iter = Bullets.begin();
		iter != Bullets.end();)
	{
		BOOL bResult = 0;
		dynamic_cast<CBullet*>(*iter)->Update(bResult);
		if (bResult == -1) { // �Ҹ�, �浹
			Safe_Delete(*iter);
			iter = Bullets.erase(iter);
		}
		else {
			iter++;
		}
	}
}

void CMainGame::Render()
{
	Rectangle(m_hDC, 0, 0, WINCX, WINCY);

	Rectangle(m_hDC, m_rcBorder.left, m_rcBorder.top, m_rcBorder.right, m_rcBorder.bottom);
	m_pMonster->Render(m_hDC);
	m_pPlayer->Render(m_hDC);

	for (auto pBullet : Bullets) {
		pBullet->Render(m_hDC);
	}
}

void CMainGame::Release()
{

	Safe_Delete<CObj*>(m_pPlayer);
	Safe_Delete<CObj*>(m_pMonster);

	for_each(Bullets.begin(), Bullets.end(), Safe_Delete<CObj*>);

	ReleaseDC(g_hWnd, m_hDC);
}
