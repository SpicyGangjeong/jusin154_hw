#include "pch.h"
#include "CBullet.h"

CBullet::CBullet() : m_ptDirection{ 0, 0 }
{

}

CBullet::~CBullet() {
	Release();
}
void CBullet::Initialize()
{
	m_tInfo = { 0.f, 0.f, 20.f, 30.f };
	m_fSpeed = 10.f;
}

void CBullet::Update()
{

}

void CBullet::Update(BOOL& _bResult)
{
	m_tInfo.fX += m_ptDirection.x * m_fSpeed;
	m_tInfo.fY += m_ptDirection.y * m_fSpeed;
	__super::Update_Rect();


	RECT rc{};
	if (IntersectRect(&rc, &m_tRect, m_Enemy->Get_Rect())) {
		_bResult = -1;
		return;
	}


	if (IntersectRect(&rc, &m_tRect, m_lprcBorder)) {
		if (rc.left != m_tRect.left ||
			rc.top != m_tRect.top ||
			rc.right != m_tRect.right ||
			rc.bottom != m_tRect.bottom) {
			_bResult = -1;
			return;
		}
	}
}

void CBullet::Render(HDC hDC)
{
	Ellipse(hDC,
		m_tRect.left, m_tRect.top,
		m_tRect.right, m_tRect.bottom );
}

void CBullet::Release()
{

}

void CBullet::Set_Direction(POINT ptDir)
{
	m_ptDirection.x = ptDir.x;
	m_ptDirection.y = ptDir.y;
}

void CBullet::Set_Position(FLOAT fPosX, FLOAT fPosY)
{
	m_tInfo.fX = fPosX;
	m_tInfo.fY = fPosY;
}