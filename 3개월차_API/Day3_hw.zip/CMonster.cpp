#include "pch.h"
#include "CMonster.h"

CMonster::CMonster() : m_iDirection(1)
{

}

CMonster::~CMonster()
{
	Release();
}

void CMonster::Initialize()
{
	m_tInfo = { WINCX / 2.f, WINCY / 4.f, 100.f, 100.f };
	m_fSpeed = 10.f;
}

void CMonster::Update()
{
	m_tInfo.fX += m_iDirection * m_fSpeed;
	__super::Update_Rect();

	RECT rc{};
	if (IntersectRect(&rc, &m_tRect, m_lprcBorder)) {
		if (rc.left != m_tRect.left ||
			rc.top != m_tRect.top ||
			rc.right != m_tRect.right ||
			rc.bottom != m_tRect.bottom) {
			m_iDirection *= -1;
			m_tInfo.fX += m_iDirection * m_fSpeed;
			__super::Update_Rect();
		}
	}
}

void CMonster::Render(HDC hDC)
{
	Rectangle(hDC, 
		m_tRect.left,	m_tRect.top,
		m_tRect.right,	m_tRect.bottom);
}

void CMonster::Release()
{
}
