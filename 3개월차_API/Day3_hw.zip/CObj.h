#pragma once

#include "Define.h"

class CObj
{
public:
	CObj();
	virtual ~CObj();

public:
	const INFO* Get_Info() { return &m_tInfo; }

public:
	virtual void	Initialize()PURE;
	virtual void	Update()PURE;
	virtual void	Render(HDC hDC)PURE;
	virtual void	Release()PURE;

public:
	void		Update_Rect();
	void		Set_Border(LPRECT _border);
	LPRECT		Get_Rect();
	void		Set_Hostile(CObj* _enemy);
protected:
	INFO		m_tInfo;
	RECT		m_tRect;
	LPRECT		m_lprcBorder;

	float		m_fSpeed;
	CObj*		m_Enemy;

};

