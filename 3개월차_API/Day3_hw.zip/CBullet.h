#pragma once
#include "CObj.h"
class CBullet :
    public CObj
{
public:
    CBullet();
    ~CBullet();

    void Initialize() override;
    void Update() override;
    void Update(BOOL& _bResult);
    void Render(HDC hDC) override;
    void Release() override;

    void Set_Direction(POINT _ptDir);
    void Set_Position(FLOAT fPosX, FLOAT fPosY);
private:
    POINT m_ptDirection;
};

