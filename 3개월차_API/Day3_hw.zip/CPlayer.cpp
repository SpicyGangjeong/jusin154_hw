#include "pch.h"
#include "CPlayer.h"

CPlayer::CPlayer() : m_pBulletList(nullptr)
{
}

CPlayer::~CPlayer()
{
	Release();
}

void CPlayer::Initialize()
{
	m_tInfo = { WINCX / 2.f, WINCY / 2.f, 100.f, 100.f };
	m_fSpeed = 10.f;
}

void CPlayer::Update()
{
	Key_Input();
	__super::Update_Rect();

	RECT rc{};
	if (IntersectRect(&rc, &m_tRect, m_lprcBorder)) {
		if (rc.left != m_tRect.left ||
			rc.top != m_tRect.top ||
			rc.right != m_tRect.right ||
			rc.bottom != m_tRect.bottom) {
			int width = m_tInfo.fCX - (rc.right - rc.left);
			int height = m_tInfo.fCY - (rc.bottom - rc.top);

			if (m_tRect.left < rc.left) {
				m_tInfo.fX += width;
			}
			else if (m_tRect.right > rc.right) {
				m_tInfo.fX -= width;
			}

			if (m_tRect.top < rc.top) {
				m_tInfo.fY += height;
			}
			else if (m_tRect.bottom > rc.bottom) {
				m_tInfo.fY -= height;
			}
		}
	}
	__super::Update_Rect();
}

void CPlayer::Render(HDC hDC)
{
	Rectangle(hDC, 
		m_tRect.left, m_tRect.top, 
		m_tRect.right, m_tRect.bottom );
}

void CPlayer::Release()
{
}

void CPlayer::Set_BulletList(list<CObj*>* _pBulletList)
{
	m_pBulletList = _pBulletList;
}

void CPlayer::Key_Input()
{
	if (GetAsyncKeyState(VK_RIGHT))
	{
		m_tInfo.fX += m_fSpeed;
	}

	if (GetAsyncKeyState(VK_LEFT))
	{
		m_tInfo.fX -= m_fSpeed;
	}

	if (GetAsyncKeyState(VK_UP))
	{
		m_tInfo.fY -= m_fSpeed;
	}

	if (GetAsyncKeyState(VK_DOWN))
	{
		m_tInfo.fY += m_fSpeed;
	}

	if (GetAsyncKeyState('W')) {
		InsertBullet(PTUP);
	}

	if (GetAsyncKeyState('A')) {
		InsertBullet(PTLEFT);
	}

	if (GetAsyncKeyState('S')) {
		InsertBullet(PTDOWN);
	}

	if (GetAsyncKeyState('D')) {
		InsertBullet(PTRIGHT);
	}
}

void CPlayer::InsertBullet(PTDIR ptDIr)
{
	CBullet* pbullet = new CBullet;
	pbullet->Initialize();
	pbullet->Set_Position(m_tInfo.fX, m_tInfo.fY);
	pbullet->Set_Hostile(m_Enemy);
	pbullet->Set_Direction(arrPTDIR[ptDIr]);
	pbullet->Set_Border(m_lprcBorder);
	m_pBulletList->push_back(pbullet);
}
