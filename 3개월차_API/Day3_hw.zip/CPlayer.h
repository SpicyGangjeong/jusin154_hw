#pragma once
#include "CObj.h"
#include "CBullet.h"

class CPlayer :   public CObj
{
public:
	CPlayer();
	virtual ~CPlayer();

public:
	void Initialize() override;
	void Update() override;
	void Render(HDC hDC) override;
	void Release() override;

	void Set_BulletList(list<CObj*>* _pBulletList);
private:
	void	Key_Input();
	void	InsertBullet(PTDIR _value);
	list<CObj*>* m_pBulletList;
};

