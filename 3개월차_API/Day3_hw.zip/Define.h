#pragma once

#define WINCX 800
#define WINCY 600

#define	PI		3.141592f
#define PURE		= 0

extern HWND    g_hWnd;

template<typename T>
void Safe_Delete(T& p)
{
	if (p)
	{
		delete p;
		p = nullptr;
	}
}

typedef struct tagInfo
{
	float	fX;
	float	fY;
	float	fCX;
	float	fCY;

}INFO;

// ��, ��, ��, ��
typedef enum tagPointerDirection {
	PTLEFT,
	PTUP,
	PTRIGHT,
	PTDOWN,
}PTDIR;


static POINT arrPTDIR[4] = {
	{-1, 0},
	{ 0, -1 },
	{ 1, 0 },
	{ 0, 1 },
};

// 
// #define PTLEFT	{-1, 0}
// #define PTUP		{0, -1}
// #define PTRIGHT	{1, 0}
// #define PTDOWN	{0, 1}
// 

