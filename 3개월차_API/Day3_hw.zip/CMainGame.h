#pragma once

#include "CPlayer.h"
#include "CMonster.h"

class CMainGame
{
public:
	CMainGame();
	~CMainGame();

public:
	void		Initialize();
	void		Update();
	void		Render();
	void		Release();

private:
	HDC		m_hDC;
	CObj*	m_pPlayer;
	CObj*	m_pMonster;
	RECT	m_rcBorder;
	list<CObj*> Bullets;

};