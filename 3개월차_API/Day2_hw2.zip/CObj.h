#pragma once

#include "Define.h"

class CObj abstract
{
public:
	CObj();
	virtual ~CObj();
	virtual void Render(HDC _hDC, LPRECT _drawRect, LPPOINT _drawPoint, double _drawRadius) = 0;
	virtual void Initialize(LONG x, LONG y) = 0;
	virtual void Update() = 0;
	virtual void Release() = 0;

public:
	POINT m_pivot;
};

