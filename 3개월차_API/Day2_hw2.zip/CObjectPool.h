#pragma once

template<typename T>
class CObjectPool
{
private:
	static CObjectPool Instance;

public:
	CObjectPool();
	~CObjectPool();


	void Initialize();
	void Update();
	void Release();
};

