#pragma once
#include "CObj.h"
class CPlayer :
    public CObj
{
public:
    CPlayer();
    ~CPlayer();
    // CObj��(��) ���� ��ӵ�
    void Render(HDC _hDC, LPRECT _drawRect, LPPOINT _drawPoint, double _drawRadius) override;
    void Initialize(LONG x, LONG y) override;
    void Update() override;
    void Release() override;
};

