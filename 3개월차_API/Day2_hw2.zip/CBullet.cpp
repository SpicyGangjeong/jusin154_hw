#include "pch.h"
#include "CBullet.h"

CBullet::CBullet()
{
    m_pivot.x = 0;
    m_pivot.y = 0;
}

CBullet::~CBullet()
{
    Release();
}

void CBullet::Render(HDC _hDC, LPRECT _drawRect, LPPOINT _drawPoint, double _drawRadius)
{
    HBRUSH hClearBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
    HPEN hRedPen = (HPEN)CreatePen(PS_SOLID, 0, 0x000000FF);
    HBRUSH hMainBrush = (HBRUSH)SelectObject(_hDC, hClearBrush);
    HPEN hMainPen = (HPEN)SelectObject(_hDC, hRedPen);
    Rectangle(_hDC, m_pivot.x + _drawRect->left,
        m_pivot.y + _drawRect->top,
        m_pivot.x + _drawRect->right,
        m_pivot.y + _drawRect->bottom);
    SelectObject(_hDC, hMainBrush);
    SelectObject(_hDC, hMainPen);

    Ellipse(_hDC, 
        m_pivot.x + _drawRect->left, 
        m_pivot.y + _drawRect->top,
        m_pivot.x + _drawRect->right,
        m_pivot.y + _drawRect->bottom);

}

void CBullet::Initialize(LONG x, LONG y)
{
    m_pivot.x = x;
    m_pivot.y = y;
}

void CBullet::Update()
{
}

void CBullet::Release()
{
}
