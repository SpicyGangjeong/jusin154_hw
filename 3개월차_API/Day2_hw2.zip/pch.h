#pragma once

#include "framework.h"
#include "list"

using namespace std;