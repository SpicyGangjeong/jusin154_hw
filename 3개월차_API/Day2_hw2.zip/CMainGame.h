#pragma once
#include "Define.h"
#include "CObj.h"
#include "CPlayer.h"
#include "CBullet.h"

class CMainGame
{
public:
	CMainGame();
	~CMainGame();

	void Initialize();
	void Render();
	void Update();
	void Release();

	void KeyProcedure();
	void LogicProcedure();
	void PhysicsProcedure();
private:
	HDC m_hDC;
	CObj* m_pPlayer;
private:
	list<CBullet*> BulletLists;
	RECT rectMainWindow;
	POINT pointMain; 
	RECT rectBullet; 
};

