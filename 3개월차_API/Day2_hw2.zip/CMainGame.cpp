#include "pch.h"
#include "CMainGame.h"

CMainGame::CMainGame()
{
	m_hDC = nullptr;
	m_pPlayer = nullptr;
	SetTimer(g_hWnd, 0, 0, 0);
	rectMainWindow = { 0, 0, WINCX, WINCY };
	pointMain = { 0, 0 };
	rectBullet = { 0, 0, 100, 100 };
}

CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Initialize()
{
	m_hDC = GetDC(g_hWnd);
	if (nullptr == m_pPlayer) {
		m_pPlayer = new CPlayer();
		m_pPlayer->Initialize(0, 0);
	}
}

void CMainGame::Render()
{
	HDC memDC = CreateCompatibleDC(m_hDC);
	HBITMAP memBitmap = CreateCompatibleBitmap(m_hDC, WINCX, WINCY);
	HBITMAP oldBitmap = (HBITMAP)SelectObject(memDC, memBitmap);


	HBRUSH hBrush = CreateSolidBrush(RGB(255, 255, 255)); // ���ϴ� ��
	FillRect(memDC, &rectMainWindow, hBrush);
	DeleteObject(hBrush);

	Ellipse(memDC, rectMainWindow.left, rectMainWindow.top, rectMainWindow.right, rectMainWindow.bottom);
	m_pPlayer->Render(memDC, &rectMainWindow, &pointMain, 0);
	for (auto pBullet: BulletLists) {
		pBullet->Render(memDC, &rectBullet, &pointMain, 0);
	}

	BitBlt(m_hDC, 0, 0, WINCX, WINCY, memDC, 0, 0, SRCCOPY);
	SelectObject(memDC, oldBitmap);
	DeleteObject(memBitmap);
	DeleteDC(memDC);
}

void CMainGame::Update()
{
	KeyProcedure();
	LogicProcedure();
	PhysicsProcedure();

}

void CMainGame::Release()
{
	ReleaseDC(g_hWnd, m_hDC);
	Safe_Delete(m_pPlayer);
}

void CMainGame::KeyProcedure()
{
	// ����Ű ó��
	//TODO: �밢�������� �̵� �� ����ȭ �������
	int speed = 10;
	if (0 < (0x8000 & GetAsyncKeyState(VK_UP))) {
		m_pPlayer->m_pivot.y -= speed;
	}
	if (0 < (0x8000 & GetAsyncKeyState(VK_DOWN))) {
		m_pPlayer->m_pivot.y += speed;
	}
	if (0 < (0x8000 & GetAsyncKeyState(VK_LEFT))) {
		m_pPlayer->m_pivot.x -= speed;
	}
	if (0 < (0x8000 & GetAsyncKeyState(VK_RIGHT))) {
		m_pPlayer->m_pivot.x += speed;
	}

	// ���콺 ó��
	if (false) {}

	// 
	if (0 < (0x8000 & GetAsyncKeyState(VK_SPACE))) {
		CBullet* b = new CBullet();
		b->Initialize(	m_pPlayer->m_pivot.x + ((rectMainWindow.right - rectMainWindow.left) / 2) - ((rectBullet.right - rectBullet.left) / 2),
						m_pPlayer->m_pivot.y + ((rectMainWindow.bottom - rectMainWindow.top) / 2) - ((rectBullet.bottom - rectBullet.top) / 2));
		BulletLists.push_back(b);
	}
}

void CMainGame::LogicProcedure()
{
	for (list<CBullet*>::iterator iter = BulletLists.begin(); iter != BulletLists.end();) {
		(*iter)->m_pivot.y -= 10;
		if ((*iter)->m_pivot.y < 0) { //TODO: �ǹ� ��ġ �Ӹ��� �ƴ϶� �Ѿ� ���Ǳ����� ���� ���� �ȿ� ������ üũ�ؾ���
			CBullet* pb = *iter;
			iter = BulletLists.erase(iter);
			Safe_Delete(pb);
		}
		else {
			iter++;
		}
	}
}

void CMainGame::PhysicsProcedure()
{
}
