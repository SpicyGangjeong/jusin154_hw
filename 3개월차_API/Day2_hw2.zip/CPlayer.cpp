#include "pch.h"
#include "CPlayer.h"

CPlayer::CPlayer()
{
    m_pivot.x = 0;
    m_pivot.y = 0;
}

CPlayer::~CPlayer()
{
	Release();
}

void CPlayer::Render(HDC _hDC, LPRECT _drawRect, LPPOINT _drawPoint, double _drawRadius)
{
    HBRUSH hClearBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
    HPEN hRedPen = (HPEN)CreatePen(PS_SOLID, 0, 0x000000FF);
    HBRUSH hMainBrush = (HBRUSH)SelectObject(_hDC, hClearBrush);
    HPEN hMainPen = (HPEN)SelectObject(_hDC, hRedPen);
    Rectangle(_hDC,     m_pivot.x + _drawRect->left,
                        m_pivot.y + _drawRect->top,
                        m_pivot.x + _drawRect->right,
                        m_pivot.y + _drawRect->bottom);
    SelectObject(_hDC, hMainBrush);
    SelectObject(_hDC, hMainPen);

    int blockSizeX = (_drawRect->right - _drawRect->left) / 12;
    int blockSizeY = (_drawRect->bottom - _drawRect->top) / 9;
    MoveToEx(_hDC,  m_pivot.x + blockSizeX * 2,             m_pivot.y + blockSizeY * 3,     NULL);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 2,             m_pivot.y + blockSizeY * 4);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 4,             m_pivot.y + blockSizeY * 6);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 6,             m_pivot.y + blockSizeY * 7);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 8,             m_pivot.y + blockSizeY * 6);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 10,            m_pivot.y + blockSizeY * 4);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 10,            m_pivot.y + blockSizeY * 3);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 9,             m_pivot.y + blockSizeY * 2);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 3,             m_pivot.y + blockSizeY * 2);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 2,             m_pivot.y + blockSizeY * 3);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 10,            m_pivot.y + blockSizeY * 3);
    MoveToEx(_hDC,  m_pivot.x + blockSizeX * 10,            m_pivot.y + blockSizeY * 4,     NULL);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 2,             m_pivot.y + blockSizeY * 4);
    MoveToEx(_hDC,  m_pivot.x + blockSizeX * 4,             m_pivot.y + blockSizeY * 6,     NULL);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 8,             m_pivot.y + blockSizeY * 6);
    MoveToEx(_hDC,  m_pivot.x + int(blockSizeX * 4.5f),     m_pivot.y + blockSizeY * 2,     NULL);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 4,             m_pivot.y + blockSizeY * 3);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 4,             m_pivot.y + blockSizeY * 4);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 5,             m_pivot.y + blockSizeY * 6);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 6,             m_pivot.y + blockSizeY * 7);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 7,             m_pivot.y + blockSizeY * 6);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 8,             m_pivot.y + blockSizeY * 4);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 8,             m_pivot.y + blockSizeY * 3);
    LineTo(_hDC,    m_pivot.x + int(blockSizeX * 7.5),      m_pivot.y + blockSizeY * 2);
    MoveToEx(_hDC,  m_pivot.x + blockSizeX * 6,             m_pivot.y + blockSizeY * 2,     NULL);
    LineTo(_hDC,    m_pivot.x + blockSizeX * 6,             m_pivot.y + blockSizeY * 7);
}

void CPlayer::Initialize(LONG x, LONG y)
{
	m_pivot.x = x;
	m_pivot.y = y;
}

void CPlayer::Update()
{
}

void CPlayer::Release()
{
}
