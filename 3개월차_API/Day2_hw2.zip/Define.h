#pragma once

#define WINCX 800
#define WINCY 600

extern HWND		g_hWnd;


template<typename T>
void Safe_Delete(T& p) {
	if (p) {
		delete p;
		p = nullptr;
	}
}

template<typename T>
void Safe_Delete_Array(T& p) {
	if (p) {
		delete[] p;
		p = nullptr;
	}
}