#include "pch.h"
#include "CObj.h"

CObj::CObj()
{
	m_pivot = { 0, 0 };
}

CObj::~CObj()
{
}
