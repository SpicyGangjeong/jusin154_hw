#include "pch.h"
#include "CObjectPool.h"
